﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApplication1.Controllers
{
    // TEST: http://localhost:8561/Home/InputForm

    public class AboutController : Controller
    {
        // GET: About
        public ActionResult Index()
        {
            // display /Shared/_Layout.cshtml as master page
            // 'View > About > index.cshtml' will be displayed to '@RenderBody()'

            return View();
        }
    }
}