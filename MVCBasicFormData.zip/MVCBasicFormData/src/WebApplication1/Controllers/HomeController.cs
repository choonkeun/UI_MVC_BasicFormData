﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApplication1.Controllers
{
    // TEST: http://localhost:8561/Home/InputForm

    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            // display /Shared/_Layout.cshtml as master page
            // 'Home controller > index.cshtml' will be displayed to '@RenderBody()'
            // <div class="jumbotron">

            ViewData["ViewData"] = "This is View Data";
            ViewBag.ViewBagInt= 100;
            ViewBag.ViewBagString = "This is ViewBag string";

            return View();
        }

        // http://localhost:8561/Home/InputForm
        public ActionResult InputForm()
        {
            // No use '/Shared/_Layout.cshtml'
            // 'View > Home > InputForm.cshtml' will be displayed to '@RenderBody()'

            //controller to Controller               variable pass is TempData
            //controller to View                     variable pass is ViewData/ViewBag
            //View       to controller               variable pass is QueryString, POST, Hidden Field
            //controller-View, controller-controller variable pass is session

            ViewBag.Name = "testName";
            ViewBag.Email = "test.Name@contoso.com";
            ViewBag.Password = "pa$$w0rd";

            return View();
        }

        public ActionResult Register()
        {
            TempData["Message"] = "Your application description page.";
            TempData["IntValue"] = 100;

            string Name = Request.Form["Name"].ToString();
            string Email = Request.Form["Email"].ToString();
            string Password = Request.Form["Password"].ToString();

            TempData["Name"] = Name;
            TempData["Email"] = Email;
            TempData["Password"] = Password;

            return RedirectToAction("ReceivedValues");
        }

        public ActionResult ReceivedValues()
        {
            int? length1 = Request.Form["Name"]?.Length; // null if length is null   
            string Name1 = length1 != null ? Request.Form["Name"].ToString() : string.Empty;

            int? length2 = Request.Form["Email"]?.Length; // null if length is null   
            string Email2 = length2 != null ? Request.Form["Email"].ToString() : string.Empty;

            int? length3 = Request.Form["Email"]?.Length; // null if length is null   
            string Password3 = length3 != null ? Request.Form["Password"].ToString() : string.Empty;

            string Name = TempData["Name"].ToString();
            string Email = TempData["Email"].ToString();
            string Password = TempData["Password"].ToString();

            string message = TempData["Message"].ToString();
            int intValue = Convert.ToInt32(TempData["IntValue"]);

            ViewBag.Name1 = Name1;
            ViewBag.Email2 = Email2;
            ViewBag.Password3 = Password3;

            Session["Name"] = Name;
            Session["Email"] = Email;
            Session["Password"] = Password;

            return RedirectToAction("Index", "Contact"); 
            //return View();
        }

    }
}